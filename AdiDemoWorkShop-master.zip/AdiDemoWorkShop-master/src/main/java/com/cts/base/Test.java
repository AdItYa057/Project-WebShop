package com.cts.base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {
	public static void main(String dolly[])
	{
		System.setProperty("", "");
		WebDriver driver = new ChromeDriver();
	}

}
